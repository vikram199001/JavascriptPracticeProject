console.log(data.results[0].members);
const member1 = data.results[0].members;

function generateTable() {
    var body = document.getElementsByTagName('body')[0];
    var tabl = document.createElement('table');

    tabl.setAttribute('class', "table table-bordered  table-hover table-primary table-fixed")
    var head = document.createElement('thead');
    var rowq = document.createElement("tr");
    var celld = document.createElement('td');
    var text0 = document.createTextNode('Name');
    celld.appendChild(text0);
    rowq.appendChild(celld);

    var cell2 = document.createElement('td');
    var text1 = document.createTextNode('Party');
    cell2.appendChild(text1);
    rowq.appendChild(cell2);

    var cell3 = document.createElement("td");
    var text2 = document.createTextNode("States");
    cell3.appendChild(text2);
    rowq.appendChild(cell3);

    var cell4 = document.createElement("td");
    var text4 = document.createTextNode("Years in Office");
    cell4.appendChild(text4);
    rowq.appendChild(cell4);

    var cell5 = document.createElement("td");
    var text5 = document.createTextNode("%Votes w/Party");
    cell5.appendChild(text5);
    rowq.appendChild(cell5);
    head.appendChild(rowq);
    tabl.appendChild(head);

    var tablBody = document.createElement('tbody');

    for (i = 0; i < member1.length; i++) {
        var row = document.createElement("tr");
        if (member1[i].middle_name == null) {
            member1[i].middle_name = ""
        }


        row.insertCell().innerHTML = (member1[i].first_name + " " + member1[i].middle_name + " " + member1[i].last_name).link(member1[i].url);

        row.insertCell().innerHTML = member1[i].party;
        row.insertCell().innerHTML = member1[i].state;
        row.insertCell().innerHTML = member1[i].seniority;
        row.insertCell().innerHTML = member1[i].votes_with_party_pct;
        var link = document.createElement('a');
        link.setAttribute('href', data.url);


        tablBody.appendChild(row);
    }
    tabl.appendChild(tablBody);
    body.appendChild(tabl);

}
generateTable()